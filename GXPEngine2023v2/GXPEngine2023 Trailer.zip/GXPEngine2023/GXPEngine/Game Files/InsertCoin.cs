﻿using System;                                   // System contains a lot of default C# libraries 
using GXPEngine;                                // GXPEngine contains the engine
using System.Drawing;
using TiledMapParser;
public class InsertCoin : AnimationSprite
{
    int i;
    public InsertCoin(TiledObject obj = null) : base("Assets/Boxes/InsertCoin.png", 1, 1)
    {
    }

    void Update()
    {
        if (i > 0)
            visible = true;
        else
            visible = false;
        if(i < -30)
            i = 30;
        i--;
    }
}
