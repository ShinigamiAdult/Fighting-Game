﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GXPEngine
{

    public class Tiles : AnimationSprite 
    {
        public Tiles(string sprite, int colm, int row) : base(sprite, colm, row)
        {

        }
    }
}